import 'package:flutter/material.dart';

void main() => runApp(const GroceryExpressApp());

class GroceryExpressApp extends StatelessWidget {
  const GroceryExpressApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Grocery Express',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xfff7f8f5),
      ),
      home: const HomePage(),
    );
  }
}

class Product {
  final String name;
  final String unit;
  final int price;
  final IconData icon;
  const Product(this.name, this.unit, this.price, this.icon);
}

const products = <Product>[
  Product('Fresh Milk', '1 litre', 60, Icons.local_drink),
  Product('Brown Bread', '400 g', 45, Icons.bakery_dining),
  Product('Rice', '5 kg', 320, Icons.grass),
  Product('Potato', '1 kg', 35, Icons.eco),
  Product('Tomato', '1 kg', 40, Icons.spa),
  Product('Cooking Oil', '1 litre', 140, Icons.water_drop),
  Product('Eggs', '12 pcs', 85, Icons.egg_alt),
  Product('Apple', '1 kg', 160, Icons.apple),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Map<Product, int> cart = {};
  int tab = 0;
  String search = '';

  void add(Product p) => setState(() => cart[p] = (cart[p] ?? 0) + 1);
  void remove(Product p) => setState(() {
        final n = (cart[p] ?? 0) - 1;
        if (n <= 0) {
          cart.remove(p);
        } else {
          cart[p] = n;
        }
      });

  int get cartCount => cart.values.fold(0, (a, b) => a + b);
  int get total => cart.entries.fold(0, (s, e) => s + e.key.price * e.value);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Grocery Express', style: TextStyle(fontWeight: FontWeight.w800)),
            Text('Fresh groceries at your door', style: TextStyle(fontSize: 12)),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => setState(() => tab = 1),
            icon: Badge(label: Text('$cartCount'), isLabelVisible: cartCount > 0, child: const Icon(Icons.shopping_cart_outlined)),
          ),
        ],
      ),
      body: tab == 1 ? _cartPage() : _homePage(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Cart'),
        ],
      ),
    );
  }

  Widget _homePage() {
    final shown = products.where((p) => p.name.toLowerCase().contains(search.toLowerCase())).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Colors.green.shade700, borderRadius: BorderRadius.circular(22)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Quick & easy shopping', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('Order daily essentials in a few taps.', style: TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 14),
        TextField(
          onChanged: (v) => setState(() => search = v),
          decoration: InputDecoration(
            hintText: 'Search groceries...', prefixIcon: const Icon(Icons.search),
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 20),
        const Text('Popular groceries', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: shown.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .78),
          itemBuilder: (_, i) {
            final p = shown[i];
            return Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(child: Center(child: Icon(p.icon, size: 62, color: Colors.green.shade600))),
                  Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(p.unit, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                  const SizedBox(height: 6),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('₹${p.price}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    FilledButton(onPressed: () => add(p), child: const Text('Add')),
                  ]),
                ]),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _cartPage() {
    if (cart.isEmpty) {
      return const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.shopping_cart_outlined, size: 80), SizedBox(height: 12), Text('Your cart is empty', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), SizedBox(height: 6), Text('Add some groceries to get started.') ]));
    }
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Your Cart', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...cart.entries.map((e) => Card(child: ListTile(leading: Icon(e.key.icon, color: Colors.green), title: Text(e.key.name), subtitle: Text('₹${e.key.price} × ${e.value}'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => remove(e.key), icon: const Icon(Icons.remove_circle_outline)), Text('${e.value}'), IconButton(onPressed: () => add(e.key), icon: const Icon(Icons.add_circle_outline))])))),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Total', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text('₹$total', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))]),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _checkout(), icon: const Icon(Icons.check), label: const Text('Place Order'))),
      ]))),
    ]);
  }

  void _checkout() {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Order placed!'),
      content: Text('Your Grocery Express order of ₹$total has been placed.'),
      actions: [TextButton(onPressed: () { Navigator.pop(context); setState(() { cart.clear(); tab = 0; }); }, child: const Text('Done'))],
    ));
  }
}
