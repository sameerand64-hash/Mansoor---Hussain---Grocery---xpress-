# Grocery Express

A simple Flutter grocery shopping app with search, products, cart, quantity controls and a demo checkout.

## GitHub APK build

The included GitHub Actions workflow generates the Android project from scratch, gets dependencies, and builds a release APK. Run **Actions → Build Flutter APK → Run workflow**. The APK is uploaded as the `grocery-express-apk` artifact.
